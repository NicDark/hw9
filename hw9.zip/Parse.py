"""

class Material():
    def __init__(self, uts=None, ys=None, modulus=None, staticFactor=None):
        self.uts = uts
        self.ys = ys
        self.E=modulus
        self.staticFactor=staticFactor

    def __init__(self):
        self.title=None
        self.links=[]
        self.nodes=[]
        self.material=Material()
"""

filename = 'Truss Design Input File 1.txt'
f1 = open(filename, 'r')
data = list(f1.readlines())
f1.close()

for x in range(len(data)):
  print(f"{x}: {data[x]}")

MaterialData = [data[x].split(sep=",") for x in range(len(data)) if data[x].find("Material") == 0]
NodeData = [data[x].split(sep=",") for x in range(len(data)) if data[x].find("node") == 0]
LinkData = [data[x].split(sep=",") for x in range(len(data)) if data[x].find("link") == 0]
Title = [data[x].split(sep=",") for x in range(len(data)) if data[x].find("Title") == 0]
staticFactor = [data[x].split(sep=",") for x in range(len(data)) if data[x].find("Static_factor") == 0]

UTS = float(MaterialData[0][1])
SY = float(MaterialData[0][2])
E = float(MaterialData[0][3])

links = [[LinkData[x][1], LinkData[x][2]] for x in range(len(LinkData))]

nodes = [[NodeData[x][1], NodeData[x][2],NodeData[x][3]] for x in range(len(NodeData))]

print(staticFactor)
def displayReport(self, truss=None):
  st = '\tTruss Design Report\n'
  st += 'Title:  {}\n'.format(truss.title)
  st += 'Static Factor of Safety:  {:0.2f}\n'.format(truss.material.staticFactor)
  st += 'Ultimate Strength:  {:0.2f}\n'.format(truss.material.uts)
  st += 'Yield Strength:  {:0.2f}\n'.format(truss.material.ys)
  st += 'Modulus of Elasticity:  {:0.2f}\n'.format(truss.material.E)
  st += '_____________Link Summary________________\n'
  st += 'Link\t(1)\t(2)\tLength\tAngle\n'
  longest = None
  for l in truss.links:
    if longest is None or l.length > longest.length:
      longest = l
    st += '{}\t{}\t{}\t{:0.2f}\t{:0.2f}\n'.format(l.name, l.node1_Name, l.node2_Name, l.length, l.angleRad)
  self.te_Report.setText(st)
  self.le_LongLinkName.setText(longest.name)
  self.le_LongLinkLength.setText("{:0.2f}".format(longest.length))
  self.le_LongLinkNode1.setText(longest.node1_Name)
  self.le_LongLinkNode2.setText(longest.node2_Name)



